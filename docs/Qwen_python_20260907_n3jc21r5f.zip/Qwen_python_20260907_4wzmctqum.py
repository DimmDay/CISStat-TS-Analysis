"""Prophet integration with fold-local FeaturePlan.

This module extends Prophet (Task 124) to support future_known and static
regressors from FeaturePlan (Task 126). Historic features (causal lags,
rolling) are NOT passed to Prophet to prevent future leakage.

Key contract:
  - Only future_known and static regressors are added via add_regressor()
  - Regressors are NOT scaled or imputed (Prophet handles internally)
  - Regressors must be available in both train and future periods
  - Each fold creates a fresh Prophet instance (per_train_fold policy)
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence

import pandas as pd

from apps.api.feature_plan import FeaturePlan, FeatureSpec
from apps.api.schemas import ModelExecutionRequest, ModelExecutionResult


def _prophet_fit_predict_with_features(
    y_train: List[float],
    horizon: int,
    train_timestamps: Sequence[str],
    future_timestamps: Sequence[str],
    feature_plan: Optional[FeaturePlan] = None,
    train_features: Optional[Dict[str, Sequence[float]]] = None,
    future_features: Optional[Dict[str, Sequence[float]]] = None,
    changepoint_prior_scale: float = 0.05,
    seasonality_prior_scale: float = 10.0,
    seasonality_mode: str = "additive",
    country_holidays: Optional[str] = None,
) -> tuple[List[float], List[float], List[float]]:
    """Fit Prophet with optional future_known/static regressors.
    
    Only future_known and static features from FeaturePlan are added
    as regressors. Historic features (causal lags, rolling) are excluded
    to prevent future leakage.
    
    Args:
        y_train: target values for train period
        horizon: forecast horizon (must match len(future_timestamps))
        train_timestamps: dates for train period
        future_timestamps: dates for forecast period
        feature_plan: optional FeaturePlan describing feature roles
        train_features: dict of feature_name -> values for train period
        future_features: dict of feature_name -> values for future period
        ...other Prophet parameters...
    
    Returns:
        (forecast, lower_80, upper_80)
    """
    from prophet import Prophet
    
    # Validate inputs
    if len(train_timestamps) != len(y_train):
        raise ValueError(
            f"Prophet requires train_timestamps to match y_train length "
            f"(got {len(train_timestamps)} timestamps for {len(y_train)} points)"
        )
    if len(future_timestamps) != horizon:
        raise ValueError(
            f"Prophet requires exactly horizon={horizon} future_timestamps "
            f"(got {len(future_timestamps)})"
        )
    
    # Build train dataframe
    train_ds = pd.to_datetime(list(train_timestamps))
    train_df = pd.DataFrame({"ds": train_ds, "y": [float(v) for v in y_train]})
    
    # Build future dataframe
    future_ds = pd.to_datetime(list(future_timestamps))
    future_df = pd.DataFrame({"ds": future_ds})
    
    # Determine which features to add as regressors
    regressor_names = []
    if feature_plan is not None:
        # Only future_known and static features can be regressors
        regressor_specs = (
            feature_plan.get_future_known_specs() + feature_plan.get_static_specs()
        )
        regressor_names = [s.name for s in regressor_specs]
    
    # Add regressors to train and future dataframes
    if regressor_names and train_features and future_features:
        for name in regressor_names:
            if name in train_features and name in future_features:
                train_values = list(train_features[name])
                future_values = list(future_features[name])
                
                if len(train_values) != len(train_df):
                    raise ValueError(
                        f"Regressor {name}: train length {len(train_values)} "
                        f"!= expected {len(train_df)}"
                    )
                if len(future_values) != len(future_df):
                    raise ValueError(
                        f"Regressor {name}: future length {len(future_values)} "
                        f"!= expected {len(future_df)}"
                    )
                
                train_df[name] = train_values
                future_df[name] = future_values
    
    # Create and fit Prophet model
    model = Prophet(
        changepoint_prior_scale=float(changepoint_prior_scale),
        seasonality_prior_scale=float(seasonality_prior_scale),
        seasonality_mode=seasonality_mode,
    )
    
    # Add regressors to model
    for name in regressor_names:
        if name in train_df.columns:
            # Prophet requires explicit add_regressor for custom regressors
            model.add_regressor(name)
    
    # Add country holidays if specified
    if country_holidays is not None:
        model.add_country_holidays(country_name=country_holidays)
    
    # Fit and predict
    model.fit(train_df)
    forecast = model.predict(future_df)
    
    yhat = forecast["yhat"].astype(float).tolist()
    lower = forecast["yhat_lower"].astype(float).tolist()
    upper = forecast["yhat_upper"].astype(float).tolist()
    
    return yhat, lower, upper


def build_prophet_features_from_plan(
    request: ModelExecutionRequest,
    feature_plan: FeaturePlan,
) -> tuple[Dict[str, List[float]], Dict[str, List[float]]]:
    """Extract future_known and static features for Prophet.
    
    Prophet only uses future_known and static regressors. Historic
    features (causal lags, rolling) are excluded to prevent leakage.
    
    Returns:
        (train_features, future_features) dicts
    """
    train_features = {}
    future_features = {}
    
    # Extract future_known and static features
    for spec in feature_plan.features:
        if spec.role in {"future_known", "static"}:
            name = spec.name
            
            # Train features
            if name in request.train_features:
                train_features[name] = list(request.train_features[name])
            
            # Future features
            if name in request.future_features:
                future_features[name] = list(request.future_features[name])
    
    return train_features, future_features