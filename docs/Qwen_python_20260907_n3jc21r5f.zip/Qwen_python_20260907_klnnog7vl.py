"""Tests for Task 126: Leakage-safe supervised FeaturePlan."""
from __future__ import annotations

import pytest
import pandas as pd
import numpy as np

from apps.api.feature_plan import (
    FeaturePlan,
    FeatureSpec,
    FoldFeatureEngine,
    validate_feature_plan_for_model,
)


class TestFeaturePlan:
    """FeaturePlan validation and fingerprint tests."""
    
    def test_from_config_basic(self):
        """Basic FeaturePlan creation from config."""
        plan = FeaturePlan.from_config(
            features=[
                {"name": "lag_1", "role": "historic", "kind": "lag",
                 "source_columns": ["price"], "transform_params": {"lag": 1}},
                {"name": "rolling_3_mean", "role": "historic", "kind": "rolling",
                 "source_columns": ["price"], "transform_params": {"window": 3, "function": "mean"}},
            ],
            impute_strategy="median",
            scale_enabled=True,
        )
        
        assert plan.plan_id.startswith("fp_")
        assert len(plan.features) == 2
        assert plan.impute_strategy == "median"
        assert plan.scale_enabled is True
        assert plan.fingerprint
    
    def test_from_config_invalid_role(self):
        """Invalid feature role raises ValueError."""
        with pytest.raises(ValueError, match="Invalid feature role"):
            FeaturePlan.from_config(
                features=[{"name": "bad", "role": "invalid_role", "kind": "numeric"}]
            )
    
    def test_from_config_invalid_kind(self):
        """Invalid feature kind raises ValueError."""
        with pytest.raises(ValueError, match="Invalid feature kind"):
            FeaturePlan.from_config(
                features=[{"name": "bad", "role": "historic", "kind": "invalid_kind"}]
            )
    
    def test_fingerprint_deterministic(self):
        """Same config produces same fingerprint."""
        config = {
            "features": [{"name": "lag_1", "role": "historic", "kind": "lag"}],
            "impute_strategy": "median",
            "scale_enabled": False,
        }
        plan1 = FeaturePlan.from_config(**config)
        plan2 = FeaturePlan.from_config(**config)
        assert plan1.fingerprint == plan2.fingerprint
    
    def test_fingerprint_changes_with_config(self):
        """Different config produces different fingerprint."""
        plan1 = FeaturePlan.from_config(
            features=[{"name": "lag_1", "role": "historic", "kind": "lag"}]
        )
        plan2 = FeaturePlan.from_config(
            features=[{"name": "lag_2", "role": "historic", "kind": "lag"}]
        )
        assert plan1.fingerprint != plan2.fingerprint
    
    def test_get_specs_by_role(self):
        """Role-based spec getters work correctly."""
        plan = FeaturePlan.from_config(
            features=[
                {"name": "lag_1", "role": "historic", "kind": "lag"},
                {"name": "holiday", "role": "future_known", "kind": "calendar"},
                {"name": "entity", "role": "static", "kind": "categorical"},
            ]
        )
        
        assert len(plan.get_historic_specs()) == 1
        assert len(plan.get_future_known_specs()) == 1
        assert len(plan.get_static_specs()) == 1


class TestFoldFeatureEngine:
    """Fold-local feature transformer tests."""
    
    def test_fit_transform_basic(self):
        """Basic fit_transform with lag and rolling features."""
        plan = FeaturePlan.from_config(
            features=[
                {"name": "lag_1", "role": "historic", "kind": "lag",
                 "source_columns": ["price"], "transform_params": {"lag": 1}},
                {"name": "rolling_3", "role": "historic", "kind": "rolling",
                 "source_columns": ["price"], "transform_params": {"window": 3, "function": "mean"}},
            ],
            impute_strategy="median",
            scale_enabled=False,
        )
        
        # Create sample data
        df = pd.DataFrame({
            "price": [10.0, 11.0, 12.0, 13.0, 14.0, 15.0],
        })
        
        engine = FoldFeatureEngine(plan)
        train_features, future_features = engine.fit_transform(df)
        
        # Check lag_1
        assert "lag_1" in train_features.columns
        assert pd.isna(train_features["lag_1"].iloc[0])  # First value is NaN
        assert train_features["lag_1"].iloc[1] == 10.0  # Second value is lag of first
        
        # Check rolling_3
        assert "rolling_3" in train_features.columns
        assert train_features["rolling_3"].iloc[2] == pytest.approx(11.0)  # Mean of [10, 11, 12]
    
    def test_imputation_on_train(self):
        """Imputer is fitted on train data only."""
        plan = FeaturePlan.from_config(
            features=[
                {"name": "lag_1", "role": "historic", "kind": "lag",
                 "source_columns": ["price"], "transform_params": {"lag": 1}},
            ],
            impute_strategy="median",
        )
        
        # Data with NaN in lag_1 (first value)
        df = pd.DataFrame({"price": [10.0, 11.0, 12.0, 13.0]})
        
        engine = FoldFeatureEngine(plan)
        engine.fit(df)
        
        # Imputer should be fitted
        assert engine._imputer is not None
        assert engine._imputer.statistics_[0] == pytest.approx(10.5)  # Median of [10, 11, 12, 13]
    
    def test_scaling_on_train(self):
        """Scaler is fitted on train data only when enabled."""
        plan = FeaturePlan.from_config(
            features=[
                {"name": "lag_1", "role": "historic", "kind": "lag",
                 "source_columns": ["price"], "transform_params": {"lag": 1}},
            ],
            impute_strategy="median",
            scale_enabled=True,
        )
        
        df = pd.DataFrame({"price": [10.0, 20.0, 30.0, 40.0]})
        
        engine = FoldFeatureEngine(plan)
        engine.fit(df)
        
        # Scaler should be fitted
        assert engine._scaler is not None
    
    def test_future_known_features_pass_through(self):
        """Future_known features are not transformed."""
        plan = FeaturePlan.from_config(
            features=[
                {"name": "holiday", "role": "future_known", "kind": "numeric"},
            ],
            impute_strategy="median",
            scale_enabled=True,
        )
        
        df = pd.DataFrame({"holiday": [0, 1, 0, 1]})
        
        engine = FoldFeatureEngine(plan)
        engine.fit(df)
        train_features, future_features = engine.transform(df, is_train=True)
        
        # Future_known should not be in train_features (it's for future only)
        assert "holiday" not in train_features.columns
    
    def test_no_future_leakage_in_lags(self):
        """Lag features cannot use future values."""
        plan = FeaturePlan.from_config(
            features=[
                {"name": "lag_1", "role": "historic", "kind": "lag",
                 "source_columns": ["price"], "transform_params": {"lag": 1}},
            ],
        )
        
        # Train data (first 4 points)
        df_train = pd.DataFrame({"price": [10.0, 11.0, 12.0, 13.0]})
        
        engine = FoldFeatureEngine(plan)
        train_features, _ = engine.fit_transform(df_train)
        
        # Test data (next 2 points)
        df_test = pd.DataFrame({"price": [14.0, 15.0]})
        test_features, _ = engine.transform(df_test, is_train=False)
        
        # Lag_1 for test should use last train value (13.0), not future values
        # First test point: lag_1 = 13.0 (last train value)
        # Second test point: lag_1 = 14.0 (first test value)
        assert test_features["lag_1"].iloc[0] == 13.0
        assert test_features["lag_1"].iloc[1] == 14.0
    
    def test_feature_importance_matrix(self):
        """Feature importance matrix matches training matrix."""
        plan = FeaturePlan.from_config(
            features=[
                {"name": "lag_1", "role": "historic", "kind": "lag",
                 "source_columns": ["price"], "transform_params": {"lag": 1}},
                {"name": "rolling_3", "role": "historic", "kind": "rolling",
                 "source_columns": ["price"], "transform_params": {"window": 3}},
            ],
        )
        
        df = pd.DataFrame({"price": [10.0, 11.0, 12.0, 13.0, 14.0]})
        
        engine = FoldFeatureEngine(plan)
        engine.fit(df)
        
        importance_matrix = engine.get_feature_importance_matrix(df)
        train_features, _ = engine.transform(df, is_train=True)
        
        # Should be identical
        pd.testing.assert_frame_equal(importance_matrix, train_features)


class TestValidateFeaturePlanForModel:
    """Model capability validation tests."""
    
    def test_valid_plan_no_warnings(self):
        """Compatible plan returns no warnings."""
        plan = FeaturePlan.from_config(
            features=[
                {"name": "lag_1", "role": "historic", "kind": "lag"},
            ]
        )
        
        capabilities = {"requires_train_features": True, "supports_future_features": False}
        warnings = validate_feature_plan_for_model(plan, capabilities)
        
        assert len(warnings) == 0
    
    def test_historic_features_without_capability(self):
        """Historic features without capability raises warning."""
        plan = FeaturePlan.from_config(
            features=[
                {"name": "lag_1", "role": "historic", "kind": "lag"},
            ]
        )
        
        capabilities = {"requires_train_features": False, "supports_future_features": False}
        warnings = validate_feature_plan_for_model(plan, capabilities)
        
        assert len(warnings) == 1
        assert "historic features" in warnings[0]
    
    def test_future_known_without_capability(self):
        """Future_known features without capability raises warning."""
        plan = FeaturePlan.from_config(
            features=[
                {"name": "holiday", "role": "future_known", "kind": "numeric"},
            ]
        )
        
        capabilities = {"requires_train_features": False, "supports_future_features": False}
        warnings = validate_feature_plan_for_model(plan, capabilities)
        
        assert len(warnings) == 1
        assert "future_known features" in warnings[0]