"""Leakage-safe supervised FeaturePlan for ML and Prophet models.

Task 126: fold-local feature engineering with strict causal separation.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from hashlib import sha256
import json
from typing import Any, List, Literal, Optional, Sequence

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder


FeatureRole = Literal["historic", "future_known", "static"]
FeatureKind = Literal["lag", "rolling", "calendar", "categorical", "numeric"]


@dataclass(frozen=True)
class FeatureSpec:
    """Specification for one feature column.
    
    role: historic = train-only (causal lags, rolling)
          future_known = available in future (known regressors, holidays)
          static = constant across time (entity, category)
    kind: type of feature for lineage tracking
    """
    name: str
    role: FeatureRole
    kind: FeatureKind
    source_columns: tuple[str, ...] = field(default_factory=tuple)
    transform_params: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class FeaturePlan:
    """Immutable plan for fold-local feature engineering.
    
    This plan is part of the cohort contract and ensures no leakage:
    - All historic features are computed only on train data
    - Imputers/scalers/encoders are fitted on train only
    - Future_known features pass through unchanged (no scaling)
    - The plan is identical across all folds for fair comparison
    """
    plan_id: str
    features: List[FeatureSpec]
    impute_strategy: str = "median"
    scale_enabled: bool = False
    fingerprint: str = field(default_factory=str)
    
    @classmethod
    def from_config(
        cls,
        features: List[dict[str, Any]],
        impute_strategy: str = "median",
        scale_enabled: bool = False,
    ) -> "FeaturePlan":
        """Build a validated FeaturePlan from configuration."""
        specs = []
        for feat in features:
            role = feat.get("role", "historic")
            if role not in {"historic", "future_known", "static"}:
                raise ValueError(f"Invalid feature role: {role}")
            kind = feat.get("kind", "numeric")
            if kind not in {"lag", "rolling", "calendar", "categorical", "numeric"}:
                raise ValueError(f"Invalid feature kind: {kind}")
            specs.append(FeatureSpec(
                name=str(feat["name"]),
                role=role,  # type: ignore
                kind=kind,  # type: ignore
                source_columns=tuple(feat.get("source_columns", [])),
                transform_params=dict(feat.get("transform_params", {})),
            ))
        
        # Build fingerprint for cohort identity
        payload = {
            "features": [
                {"name": s.name, "role": s.role, "kind": s.kind,
                 "source": list(s.source_columns), "params": s.transform_params}
                for s in specs
            ],
            "impute_strategy": impute_strategy,
            "scale_enabled": scale_enabled,
        }
        encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        fingerprint = sha256(encoded).hexdigest()
        plan_id = f"fp_{fingerprint[:12]}"
        
        return cls(
            plan_id=plan_id,
            features=specs,
            impute_strategy=impute_strategy,
            scale_enabled=scale_enabled,
            fingerprint=fingerprint,
        )
    
    def get_historic_specs(self) -> List[FeatureSpec]:
        """Return specs for historic features (train-only)."""
        return [s for s in self.features if s.role == "historic"]
    
    def get_future_known_specs(self) -> List[FeatureSpec]:
        """Return specs for future_known features."""
        return [s for s in self.features if s.role == "future_known"]
    
    def get_static_specs(self) -> List[FeatureSpec]:
        """Return specs for static features."""
        return [s for s in self.features if s.role == "static"]


class FoldFeatureEngine:
    """Fold-local feature transformer with strict train-only fitting.
    
    This engine is instantiated fresh for each EDA fold. It fits
    imputers/scalers/encoders on train data only, then applies them
    to both train and test. This prevents leakage from test into train.
    
    Future_known features are NOT scaled or imputed (they are known
    in the future and should not be transformed).
    """
    
    def __init__(self, plan: FeaturePlan, random_state: int = 42):
        self.plan = plan
        self.random_state = random_state
        self._imputer: Optional[SimpleImputer] = None
        self._scaler: Optional[StandardScaler] = None
        self._encoder: Optional[OneHotEncoder] = None
        self._categorical_features: List[str] = []
        self._numeric_features: List[str] = []
        self._fitted = False
    
    def _build_historic_features(
        self, df: pd.DataFrame, is_train: bool
    ) -> pd.DataFrame:
        """Build causal features from train data only.
        
        Lags and rolling features are computed only on train slice
        to prevent future leakage. For test data, these features
        will be NaN (they cannot be computed without future values).
        """
        historic_specs = self.plan.get_historic_specs()
        if not historic_specs:
            return pd.DataFrame(index=df.index)
        
        result = pd.DataFrame(index=df.index)
        
        for spec in historic_specs:
            if spec.kind == "lag":
                source = spec.source_columns[0] if spec.source_columns else list(df.columns)[0]
                lag = int(spec.transform_params.get("lag", 1))
                result[spec.name] = df[source].shift(lag)
            
            elif spec.kind == "rolling":
                source = spec.source_columns[0] if spec.source_columns else list(df.columns)[0]
                window = int(spec.transform_params.get("window", 3))
                func = spec.transform_params.get("function", "mean")
                
                if func == "mean":
                    result[spec.name] = df[source].rolling(window, min_periods=1).mean()
                elif func == "std":
                    result[spec.name] = df[source].rolling(window, min_periods=1).std()
                elif func == "max":
                    result[spec.name] = df[source].rolling(window, min_periods=1).max()
                elif func == "min":
                    result[spec.name] = df[source].rolling(window, min_periods=1).min()
        
        return result
    
    def fit(self, df_train: pd.DataFrame) -> "FoldFeatureEngine":
        """Fit imputers/scalers/encoders on train data only."""
        if self._fitted:
            raise RuntimeError("FoldFeatureEngine already fitted")
        
        # Build historic features on train
        historic_df = self._build_historic_features(df_train, is_train=True)
        
        # Separate numeric and categorical
        self._numeric_features = [
            s.name for s in self.plan.get_historic_specs()
            if s.kind in {"lag", "rolling", "numeric"}
        ]
        self._categorical_features = [
            s.name for s in self.plan.features if s.kind == "categorical"
        ]
        
        # Fit imputer on numeric features
        if self._numeric_features:
            numeric_data = historic_df[self._numeric_features].values
            self._imputer = SimpleImputer(strategy=self.plan.impute_strategy)
            self._imputer.fit(numeric_data)
            
            # Fit scaler if enabled
            if self.plan.scale_enabled:
                imputed = self._imputer.transform(numeric_data)
                self._scaler = StandardScaler()
                self._scaler.fit(imputed)
        
        # Fit encoder on categorical features
        if self._categorical_features:
            categorical_data = historic_df[self._categorical_features].values
            self._encoder = OneHotEncoder(sparse_output=False, handle_unknown="ignore")
            self._encoder.fit(categorical_data)
        
        self._fitted = True
        return self
    
    def transform(
        self, df: pd.DataFrame, is_train: bool = False
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Transform features with train-only fitted parameters.
        
        Returns (train_features, future_features) where:
        - train_features: features for model training (historic + static)
        - future_features: features available in future (future_known only)
        """
        if not self._fitted:
            raise RuntimeError("FoldFeatureEngine not fitted")
        
        # Build all features
        historic_df = self._build_historic_features(df, is_train=is_train)
        
        # Process numeric features (impute + scale)
        if self._numeric_features and self._imputer is not None:
            numeric_data = historic_df[self._numeric_features].values
            imputed = self._imputer.transform(numeric_data)
            if self._scaler is not None:
                numeric_data = self._scaler.transform(imputed)
            else:
                numeric_data = imputed
            historic_df[self._numeric_features] = numeric_data
        
        # Process categorical features (encode)
        if self._categorical_features and self._encoder is not None:
            categorical_data = historic_df[self._categorical_features].values
            encoded = self._encoder.transform(categorical_data)
            encoded_cols = self._encoder.get_feature_names_out(self._categorical_features)
            encoded_df = pd.DataFrame(encoded, columns=encoded_cols, index=df.index)
            historic_df = historic_df.drop(columns=self._categorical_features)
            historic_df = pd.concat([historic_df, encoded_df], axis=1)
        
        # Separate by role
        historic_cols = [c for c in historic_df.columns if c.startswith(("lag_", "rolling_"))]
        future_known_cols = [s.name for s in self.plan.get_future_known_specs()]
        static_cols = [s.name for s in self.plan.get_static_specs()]
        
        # Build train features (historic + static)
        train_features = pd.DataFrame(index=df.index)
        if historic_cols:
            train_features = pd.concat([train_features, historic_df[historic_cols]], axis=1)
        if static_cols:
            train_features = pd.concat([train_features, df[static_cols]], axis=1)
        
        # Build future features (future_known only, no transformation)
        future_features = pd.DataFrame(index=df.index)
        if future_known_cols:
            available = [c for c in future_known_cols if c in df.columns]
            if available:
                future_features = df[available]
        
        return train_features, future_features
    
    def fit_transform(
        self, df_train: pd.DataFrame
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Fit on train and return (train_features, future_features)."""
        self.fit(df_train)
        return self.transform(df_train, is_train=True)
    
    def get_feature_importance_matrix(
        self, df: pd.DataFrame
    ) -> pd.DataFrame:
        """Return feature matrix for importance tracking.
        
        This is the exact matrix used in model training, enabling
        feature importance to be tied to specific fold.
        """
        train_features, _ = self.transform(df, is_train=True)
        return train_features


def validate_feature_plan_for_model(
    plan: FeaturePlan, model_capabilities: dict[str, Any]
) -> list[str]:
    """Validate that a model can use this FeaturePlan.
    
    Returns list of warnings (empty if fully compatible).
    """
    warnings = []
    
    requires_train_features = model_capabilities.get("requires_train_features", False)
    supports_future_features = model_capabilities.get("supports_future_features", False)
    
    has_historic = bool(plan.get_historic_specs())
    has_future_known = bool(plan.get_future_known_specs())
    
    if has_historic and not requires_train_features:
        warnings.append(
            f"Model does not support train_features, but FeaturePlan has historic features"
        )
    
    if has_future_known and not supports_future_features:
        warnings.append(
            f"Model does not support future_features, but FeaturePlan has future_known features"
        )
    
    return warnings