"""Tests for Task 126: Prophet integration with FeaturePlan."""
from __future__ import annotations

import pytest
import pandas as pd
from unittest.mock import Mock, patch

from apps.api.feature_plan import FeaturePlan
from apps.api.schemas import ModelExecutionRequest
from apps.api.model_impls.prophet_features import (
    _prophet_fit_predict_with_features,
    build_prophet_features_from_plan,
)


class TestProphetWithFeatures:
    """Prophet integration with future_known and static regressors."""
    
    @patch("apps.api.model_impls.prophet_features.Prophet")
    def test_prophet_without_features(self, mock_prophet_class):
        """Prophet works without FeaturePlan (Task 124 contract)."""
        mock_model = Mock()
        mock_prophet_class.return_value = mock_model
        
        forecast_df = pd.DataFrame({
            "yhat": [10.0, 11.0],
            "yhat_lower": [9.0, 10.0],
            "yhat_upper": [11.0, 12.0],
        })
        mock_model.predict.return_value = forecast_df
        
        y_train = [1.0, 2.0, 3.0]
        horizon = 2
        train_timestamps = ["2020-01-01", "2020-01-02", "2020-01-03"]
        future_timestamps = ["2020-01-04", "2020-01-05"]
        
        yhat, lower, upper = _prophet_fit_predict_with_features(
            y_train=y_train,
            horizon=horizon,
            train_timestamps=train_timestamps,
            future_timestamps=future_timestamps,
            feature_plan=None,
            train_features=None,
            future_features=None,
        )
        
        assert len(yhat) == 2
        assert len(lower) == 2
        assert len(upper) == 2
        mock_model.fit.assert_called_once()
    
    @patch("apps.api.model_impls.prophet_features.Prophet")
    def test_prophet_with_future_known_regressor(self, mock_prophet_class):
        """Prophet accepts future_known regressors."""
        mock_model = Mock()
        mock_prophet_class.return_value = mock_model
        
        forecast_df = pd.DataFrame({
            "yhat": [10.0, 11.0],
            "yhat_lower": [9.0, 10.0],
            "yhat_upper": [11.0, 12.0],
        })
        mock_model.predict.return_value = forecast_df
        
        plan = FeaturePlan.from_config(
            features=[
                {"name": "holiday", "role": "future_known", "kind": "numeric"},
            ]
        )
        
        y_train = [1.0, 2.0, 3.0]
        horizon = 2
        train_timestamps = ["2020-01-01", "2020-01-02", "2020-01-03"]
        future_timestamps = ["2020-01-04", "2020-01-05"]
        
        train_features = {"holiday": [0, 1, 0]}
        future_features = {"holiday": [1, 0]}
        
        yhat, lower, upper = _prophet_fit_predict_with_features(
            y_train=y_train,
            horizon=horizon,
            train_timestamps=train_timestamps,
            future_timestamps=future_timestamps,
            feature_plan=plan,
            train_features=train_features,
            future_features=future_features,
        )
        
        # add_regressor should be called for future_known feature
        mock_model.add_regressor.assert_called_with("holiday")
    
    @patch("apps.api.model_impls.prophet_features.Prophet")
    def test_prophet_ignores_historic_features(self, mock_prophet_class):
        """Prophet ignores historic features (causal lags, rolling)."""
        mock_model = Mock()
        mock_prophet_class.return_value = mock_model
        
        forecast_df = pd.DataFrame({
            "yhat": [10.0, 11.0],
            "yhat_lower": [9.0, 10.0],
            "yhat_upper": [11.0, 12.0],
        })
        mock_model.predict.return_value = forecast_df
        
        # Plan with historic feature (should be ignored)
        plan = FeaturePlan.from_config(
            features=[
                {"name": "lag_1", "role": "historic", "kind": "lag"},
            ]
        )
        
        y_train = [1.0, 2.0, 3.0]
        horizon = 2
        train_timestamps = ["2020-01-01", "2020-01-02", "2020-01-03"]
        future_timestamps = ["2020-01-04", "2020-01-05"]
        
        train_features = {"lag_1": [0, 1, 2]}
        future_features = {"lag_1": [3, 4]}
        
        yhat, lower, upper = _prophet_fit_predict_with_features(
            y_train=y_train,
            horizon=horizon,
            train_timestamps=train_timestamps,
            future_timestamps=future_timestamps,
            feature_plan=plan,
            train_features=train_features,
            future_features=future_features,
        )
        
        # add_regressor should NOT be called for historic feature
        mock_model.add_regressor.assert_not_called()
    
    def test_build_prophet_features_from_plan(self):
        """Extract future_known and static features for Prophet."""
        plan = FeaturePlan.from_config(
            features=[
                {"name": "holiday", "role": "future_known", "kind": "numeric"},
                {"name": "lag_1", "role": "historic", "kind": "lag"},
                {"name": "category", "role": "static", "kind": "categorical"},
            ]
        )
        
        request = ModelExecutionRequest(
            target=[1.0, 2.0, 3.0],
            horizon=2,
            train_features={
                "holiday": [0, 1, 0],
                "lag_1": [0, 1, 2],
                "category": [0, 1, 0],
            },
            future_features={
                "holiday": [1, 0],
                "lag_1": [3, 4],
                "category": [1, 0],
            },
        )
        
        train_features, future_features = build_prophet_features_from_plan(
            request, plan
        )
        
        # Should include only future_known and static
        assert "holiday" in train_features
        assert "category" in train_features
        assert "lag_1" not in train_features  # historic excluded
        
        assert "holiday" in future_features
        assert "category" in future_features
        assert "lag_1" not in future_features  # historic excluded
    
    @patch("apps.api.model_impls.prophet_features.Prophet")
    def test_prophet_regressor_length_validation(self, mock_prophet_class):
        """Regressor length must match train/future periods."""
        mock_model = Mock()
        mock_prophet_class.return_value = mock_model
        
        plan = FeaturePlan.from_config(
            features=[
                {"name": "holiday", "role": "future_known", "kind": "numeric"},
            ]
        )
        
        y_train = [1.0, 2.0, 3.0]
        horizon = 2
        train_timestamps = ["2020-01-01", "2020-01-02", "2020-01-03"]
        future_timestamps = ["2020-01-04", "2020-01-05"]
        
        # Wrong length: 2 values for 3 train points
        train_features = {"holiday": [0, 1]}
        future_features = {"holiday": [1, 0]}
        
        with pytest.raises(ValueError, match="train length"):
            _prophet_fit_predict_with_features(
                y_train=y_train,
                horizon=horizon,
                train_timestamps=train_timestamps,
                future_timestamps=future_timestamps,
                feature_plan=plan,
                train_features=train_features,
                future_features=future_features,
            )