"""Schema v7 additions for Task 126: FeaturePlan artifacts."""
from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, Field


class FeatureSpecOut(BaseModel):
    """Specification for one feature column in artifacts."""
    name: str
    role: Literal["historic", "future_known", "static"]
    kind: Literal["lag", "rolling", "calendar", "categorical", "numeric"]
    source_columns: List[str] = Field(default_factory=list)
    transform_params: Dict[str, Any] = Field(default_factory=dict)


class FeaturePlanOut(BaseModel):
    """Leakage-safe feature engineering plan (Task 126).
    
    This plan ensures no leakage:
    - Historic features are computed only on train data
    - Imputers/scalers/encoders are fitted on train only
    - Future_known features pass through unchanged
    """
    plan_id: str
    features: List[FeatureSpecOut]
    impute_strategy: str = "median"
    scale_enabled: bool = False
    fingerprint: str


class FeatureImportanceOut(BaseModel):
    """Feature importance tied to exact fold matrix."""
    feature_name: str
    importance: float
    role: Literal["historic", "future_known", "static"]
    kind: Literal["lag", "rolling", "calendar", "categorical", "numeric"]


class ModelExecutionContractV7(BaseModel):
    """Extended execution contract with FeaturePlan support."""
    version: str
    model_id: str
    family_id: str
    adapter_id: str
    objective: Literal["level_forecast", "multivariate", "volatility"]
    input_kind: Literal["univariate", "supervised", "multivariate", "panel"]
    supports_future_features: bool = False
    requires_train_features: bool = False
    feature_plan: Optional[FeaturePlanOut] = None
    signature: str


class BacktestResponseV7(BaseModel):
    """Backtest response with FeaturePlan artifacts (schema v7)."""
    # Existing fields inherited from BacktestResponse
    feature_plan: Optional[FeaturePlanOut] = None
    feature_importance: List[FeatureImportanceOut] = Field(default_factory=list)
    schema_version: Literal["v7"] = "v7"